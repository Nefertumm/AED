#include "eval.hpp"
#include <climits>
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

// ESCRIBIR SU DNI AQUI (sin puntos ni espacios)
// DNI: 

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool btisomorph(btree<int> &B1,btree<int>::iterator n1,
                btree<int> &B2,btree<int>::iterator n2) {
  // COMPLETAR AQUI...
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool btisomorph(btree<int> &B1,btree<int> &B2) {
  // COMPLETAR AQUI...
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool has_sum(set<int> &S, int M) {
  // COMPLETAR AQUI...
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int find_shift(list<int> &L1,list<int> &L2) {
  // COMPLETAR AQUI...
  return 0;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0;

  ev.eval1(btisomorph,vrbs);
  ev.eval2(has_sum,vrbs);
  ev.eval3(find_shift,vrbs);

  h1 = ev.evalr1(btisomorph,seed,0); // para SEED=123 debe dar H=759
  h2 = ev.evalr2(has_sum,seed,0);    // para SEED=123 debe dar H=288
  h3 = ev.evalr3(find_shift,seed,0); // para SEED=123 debe dar H=257

  printf("S=%03d -> H1=%03d H2=%03d H3=%03d\n",
         seed,h1,h2,h3);
  return 0;
}
