#include "eval.hpp"
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

bool is_recurrent_tree (btree<int> &T,assoc_fun_t g){
  // COMPLETAR AQUI...
}

void ordered_tree(vector<int> &V, btree<int> &t){
  // COMPLETAR AQUI...
}

void bijsubset(set<int> &S, map_fun_t f, set<int> &S1) {
  // COMPLETAR AQUI...
}

bool preimage(vector< set<int> >&VX,map_fun_t f,
              set<int> &Y,set<int> &preY) {
  // COMPLETAR AQUI...
}

int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0,h4=0;

  ev.eval_bjs(bijsubset,vrbs);
  ev.eval_pri(preimage,vrbs);
  ev.eval_irt(is_recurrent_tree,vrbs);
  ev.eval_otr(ordered_tree,vrbs);

  h1 = ev.evalr_bjs(bijsubset,seed,vrbs); // para SEED=123 debe dar H=907
  h2 = ev.evalr_pri(preimage,seed,vrbs); // para SEED=123 debe dar H=631
  h3 = ev.evalr_irt(is_recurrent_tree,seed,vrbs); // para SEED=123 debe dar H=794
  h4 = ev.evalr_otr(ordered_tree,seed,vrbs); // para SEED=123 debe dar H=069

  printf("SEED=%03d -> HASH1=%03d, HASH2=%03d, "
         "HASH3=%03d, HASH4=%03d\n",
         seed,h1,h2,h3,h4);
  return 0;
}
