#include "eval.hpp"
#include <climits>
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
typedef btree<int>::iterator bnode_t;
bool diffh(btree<int> &T,bnode_t n,int &height) {
  // COMPLETAR AQUI...
  return 0;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool diffh(btree<int> &T) {
  // COMPLETAR AQUI...
  return 0;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void only1(vector< set<int> > &VS,set<int> &S1) {
  // COMPLETAR AQUI...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool included(vector< set<int> > &VS) {
  // COMPLETAR AQUI...
  return true;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int onechild(btree<int> &T, bnode_t n) {
  // COMPLETAR AQUI...
  return 0;
}
             
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Wrapper
int onechild(btree<int> &T) {
  // COMPLETAR AQUI...
  return 0;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0,h4=0;

  ev.eval1(only1,vrbs);
  ev.eval2(included,vrbs);
  ev.eval3(diffh,vrbs);
  ev.eval4(onechild,vrbs);

  h1 = ev.evalr1(only1,seed,0); // para SEED=123 debe dar H=352
  h2 = ev.evalr2(included,seed,0); // para SEED=123 debe dar H=318
  h3 = ev.evalr3(diffh,seed,0); // para SEED=123 debe dar H=533
  h4 = ev.evalr4(onechild,seed,0); // para SEED=123 debe dar H=204

  printf("S=%03d -> H1=%03d H2=%03d H3=%03d H4=%03d\n",
         seed,h1,h2,h3,h4);
  return 0;
}
