#include "eval.hpp"
#include <cstdlib>

using namespace aed;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void large_even_list(vector< list<int> >&VL,list<int>&L) {
  // LLENAR AQUI...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void interlaced_split(list<int>&L, int m, 
                      vector< list<int> >&VL) {
  // LLENAR AQUI...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void interlaced_join(vector< list<int> >&VL, list<int>&L) {
  // LLENAR AQUI...
}

int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1,h2,h3;
  ev.eval1(large_even_list,vrbs);
  h1 = ev.eval1r(large_even_list,seed,0);
  
  ev.eval2(interlaced_split,vrbs);
  h2 = ev.eval2r(interlaced_split,seed,0);
  
  ev.eval3(interlaced_join,vrbs);
  h3 = ev.eval3r(interlaced_join,seed,0);
  // para SEED=123 debe retornar H1=581, H2=421, H3=505
  printf("SEED=%03d -> HASH1=%03d, HASH2=%03d, HASH3=%03d\n",
         seed,h1,h2,h3);
  return 0;
}
