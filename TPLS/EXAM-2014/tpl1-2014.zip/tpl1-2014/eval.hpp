#ifndef EVAL_HPP
#define EVAL_HPP

#include <cstdio>
#include <cstdlib>
#include <stdint.h>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <iostream>
#include <sstream>
using namespace std;

namespace aed {

  // Simple hasher class for the examples
  class hasher_t  {
  private:
    // BJ hash (Bob Jenkins). From
    // http://www.chasanc.com/old/hashing_func.htm
    typedef uint32_t u4; /* unsigned 4-byte type */
    typedef uint8_t u1;   /* unsigned 1-byte type */
    u4 state;

    /* The mixing step */
#define mix(a,b,c)                              \
    {                                           \
      a=a-b;  a=a-c;  a=a^(c>>13);              \
      b=b-c;  b=b-a;  b=b^(a<<8);               \
      c=c-a;  c=c-b;  c=c^(b>>13);              \
      a=a-b;  a=a-c;  a=a^(c>>12);              \
      b=b-c;  b=b-a;  b=b^(a<<16);              \
      c=c-a;  c=c-b;  c=c^(b>>5);               \
      a=a-b;  a=a-c;  a=a^(c>>3);               \
      b=b-c;  b=b-a;  b=b^(a<<10);              \
      c=c-a;  c=c-b;  c=c^(b>>15);              \
    }

    /* The whole new hash function */
    u4 bjhash(register u1* k,u4 length, u4 initval)
    // register u1 *k;        /* the key */
    // u4           length;   /* the length of the key in bytes */
    // u4           initval;  /* the previous hash, or an arbitrary value */
    {
      register u4 a,b,c;  /* the internal state */
      u4          len;    /* how many key bytes still need mixing */

      /* Set up the internal state */
      len = length;
      a = b = 0x9e3779b9;  /* the golden ratio; an arbitrary value */
      c = initval;         /* variable initialization of internal state */

      /*---------------------------------------- handle most of the key */
      while (len >= 12)
        {
          a=a+(k[0]+((u4)k[1]<<8)+((u4)k[2]<<16) +((u4)k[3]<<24));
          b=b+(k[4]+((u4)k[5]<<8)+((u4)k[6]<<16) +((u4)k[7]<<24));
          c=c+(k[8]+((u4)k[9]<<8)+((u4)k[10]<<16)+((u4)k[11]<<24));
          mix(a,b,c);
          k = k+12; len = len-12;
        }

      /*------------------------------------- handle the last 11 bytes */
      c = c+length;
      switch(len)              /* all the case statements fall through */
        {
        case 11: c=c+((u4)k[10]<<24);
        case 10: c=c+((u4)k[9]<<16);
        case 9 : c=c+((u4)k[8]<<8);
          /* the first byte of c is reserved for the length */
        case 8 : b=b+((u4)k[7]<<24);
        case 7 : b=b+((u4)k[6]<<16);
        case 6 : b=b+((u4)k[5]<<8);
        case 5 : b=b+k[4];
        case 4 : a=a+((u4)k[3]<<24);
        case 3 : a=a+((u4)k[2]<<16);
        case 2 : a=a+((u4)k[1]<<8);
        case 1 : a=a+k[0];
          /* case 0: nothing left to add */
        }
      mix(a,b,c);
      /*-------------------------------------------- report the result */
      return c;
    }

  public:
    hasher_t() { reset(); }
    void reset() { state = 0L; }
    void hash(vector<int> w) { hash(&w[0],w.size()); }
    void hash(list<int> &L) {
      list<int>::iterator q = L.begin();
      while (q!=L.end()) hash(*q++);
    }
    void hash(vector< list<int> > &VL) {
      int N = VL.size();
      for (int j=0; j<N; j++) {
        list<int> &L = VL[j];
        hash(L.size());
        hash(L);
      }
    }

    void hash(int w) {
      state = bjhash((u1*)&w,sizeof(int),state);
    }

    void hash(int *w,int n) {
      for (int j=0; j<n; j++) hash(w[j]);
    }

    uint64_t val() {
      return state;
    }


  };

  // Simple random generator class for the examples
  class randomg_t  {
  private:
    hasher_t hasher;
    uint64_t state;
  public:
    randomg_t() { reset(0); }
    void reset(uint64_t seed=0) { hasher.reset(); state=seed; }
    uint64_t rand() { 
      hasher.hash(state++); 
      return hasher.val();
    }
  };

  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  void dump(list<int> &L,string s="") {
    cout << s; 
    list<int>::iterator q = L.begin();
    while (q!=L.end()) cout << *q++ << " ";
    cout << endl;
  }

  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  void dump(vector< list<int> > &VL,string s="") {
    int N = VL.size();
    // cout << "vector length " << N << endl;
    for (int j=0; j<N; j++) {
      cout << s << "[" << j << "]: ";
      dump(VL[j]);
    }
  }

  class Eval {
    void printmap(map<int, list<bool> >& M) {
      cout << "M = {";
      map<int, list<bool> >::iterator p = M.begin();
      while (p!=M.end()) {
        cout << p->first << "->[";
        list<bool> &L = p->second;
        list<bool>::iterator q = L.begin();
        while (q!=L.end()) {
          cout << (*q ? "true" : "false");
          q++;
          if (q!=L.end()) cout << ", ";
        }
        cout << "]";
        p++;
        if (p!=M.end()) cout << ", ";
      }
      cout << "}" << endl;
    }

    list< list<int> > colas(list<int> &L) {
      list< list<int> > R;
      if (L.empty()) return R;
      list<int>::iterator it = L.begin();
      while (it != L.end()) {
        R.push_back(list<int>(it, L.end()));
        ++ it;
      }

      return R;
    }

    // Retorna todos los elementos de la lista
    // e.g.: "1 2 3 4 3 2 1" -> (1 2 3 4 3 2 1)
    void s2l(string s, list<int> &L) {
      istringstream is(s);
      int n;
      while (is >> n)
        L.push_back(n);
    }

    void prl(list<int> &L) {
      if (L.empty()) return;
      list<int>::iterator il = L.begin();
      for (; &*il != &*L.rbegin(); il ++)
        cout << *il << " ";
      cout << *il;
    }


    void s2m(string s, map<int, list<bool> > &M) {
      M.clear();
      istringstream is(s);

      int k, n, v;
      while (is >> k >> n) {
        list<bool> L;

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          L.push_back(v);
        }
        M[k] = L;
      }
    }

    void s2m(string s, map<int, list<int> > &M) {
      M.clear();
      istringstream is(s);
      int k, n, v;
      while (is >> k >> n) {
        list<int> L;
        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          L.push_back(v);
        }
        M[k] = L;
      }
    }

    // string -> vector de listas
    // (n1 L1 n2 L2 ...)
    // "3 1 2 3 4 5 4 3 2"  -> [(1 2 3) (5 4 3 2)]
    void s2vl(string s, vector< list<int> > &v) {
      istringstream is(s);
      int n1, n2;
      while (is >> n1) {
        v.push_back(list<int>());
        for (int i = 0 ; i < n1 ; i ++) {
          is >> n2;
          v.back().push_back(n2);
        }
      }
    }

    void acum_hasta(list<int> &L, int n) {
      int acum = 0;
      list<int>::iterator it = L.begin();
      while (it != L.end()) {
        acum += *it;
        it = L.erase(it);
        if (acum >= n) {
          L.insert(it, acum);
          acum = 0;
        }
      }
      if (acum > 0) L.push_back(acum);
    }

  public:

    const char *i2s(int ok) { return (ok ? "OK" : "MAL"); }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    typedef void (*large_even_list_t)(vector< list<int> >&VL,list<int>&L);
    void verificar1(int &caso,int &okt,large_even_list_t F,string svl, 
                   string sl,int vrbs=0) {
      vector< list<int> > vl;
      list<int> Luser,Lans;
      s2vl(svl,vl);
      s2l(sl,Lans);
      F(vl,Luser);
      if (vrbs) {
        printf("---------\n");
        dump(vl,"VL");
        cout << "Respuesta esperada L: ";
        prl(Lans);
        cout << endl;
      }
      int ok = (Luser == Lans);
      cout << "EJ1|Caso" << caso << ". Estado: " << i2s(ok) << endl;
      if (!ok) {
        cout << "Respuesta incorrecta, L: ";
        prl(Luser);
        cout << endl;
      }
      okt += ok; caso++;
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    void eval1(large_even_list_t F,int vrbs=0) {
      cout << "----------------\nEvaluando ejercicio 1" << endl;
      int caso = 0, ok = 0;
      verificar1(caso,ok,F,"7 0 1 2 3 4 5 7 4 0 1 2 3 5 2 2 2 1 0","2 2 2 0",vrbs);
      verificar1(caso,ok,F,"3 0 2 3 4 2 0 3 5","0 2",vrbs);
      verificar1(caso,ok,F,"1 0 3 5 7 9","0",vrbs);
      int total = caso;
      printf("ESTADO EJ1: total %d, ok %d, mal %d. Todos bien? %s\n",
             total,ok,total-ok,i2s(ok==total));
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    int eval1r(large_even_list_t F,
                    int seed,int vrbs=0) {
      int ncasos=20;
      hasher_t hasher;
      randomg_t rnd;
      rnd.reset(seed);
      for (int caso=0; caso<ncasos; caso++) {
        if (vrbs>=2) printf("Ejercicio 1. Caso %d\n",caso);
        int M=3, N=10;
        vector< list<int> > VL(M);
        for (int j=0; j<M; j++) {
          list<int> &L = VL[j];
          int NN = rnd.rand()%N;
          for (int k=0; k<NN; k++)
            L.push_back(rnd.rand()%20);
          if (vrbs>=2) {
            printf("VL[%d]: ",j); 
            prl(L); 
            cout << endl;
          }
        }
        list<int> L;
        F(VL,L);
        if (vrbs>=2) {
          printf("L: "); prl(L); cout << endl;
        }
        hasher.hash(L.size());
        hasher.hash(L);
      }
      int H = hasher.val()%1000;
      if (vrbs) printf("EJ1: SEED=%03d, HASH=%03d\n",seed,H);
      return H;
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    typedef void (*interlaced_split_t)(list<int>&L, int m, 
                                       vector< list<int> >&VL);
    int verificar2(int &caso,int &okt,interlaced_split_t F,string sl, 
                   int m,string svlans,int vrbs=0) {
      list<int> L;
      vector< list<int> > vluser,vlans;
      s2l(sl,L);
      s2vl(svlans,vlans);
      F(L,m,vluser);

      if (vrbs) {
        cout << "--------------" << endl << "Evaluando EJ2|Caso" 
             << caso << endl;
        prl(L); 
        cout << endl << "m: " << m << endl;
        cout << "Respuesta esperada: " << endl;
        dump(vlans,"VL");
        cout << endl;
      }
      int ok = (vluser == vlans);
      cout << "EJ2|Caso" << caso << ". Estado: " << i2s(ok) << endl;
      if (!ok) {
        cout << "Respuesta incorrecta, VL: ";
        dump(vluser);
        cout << endl;
      }
      if (vrbs) cout << "--------------" << endl;
      okt += ok; caso++;
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    void eval2(interlaced_split_t F,int vrbs=0) {
      cout << "----------------\nEvaluando ejercicio 2" << endl;
      int caso = 0, ok = 0;
      verificar2(caso,ok,F,"0 1 2 3 4 5 6",2,"4 0 2 4 6 3 1 3 5",vrbs);
      verificar2(caso,ok,F,"0 1 2 3 4 5 6",3,"3 0 3 6 2 1 4 2 2 5",vrbs);
      verificar2(caso,ok,F,"0 1 2 3 4 5 6 7 8",4,"3 0 4 8 2 1 5 2 2 6 2 3 7",vrbs);
      int total = caso;
      printf("ESTADO EJ2: total casos %d,"
             " ok %d, mal %d. Todos bien? %s\n",
             total,ok,total-ok,i2s(ok==total));

    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    int eval2r(interlaced_split_t F,
                    int seed,int vrbs=0) {
      int ncasos=20, NN=100, MAX=20;
      hasher_t hasher;
      randomg_t rnd;
      rnd.reset(seed);
      for (int caso=0; caso<ncasos; caso++) {
        if (vrbs>=2) printf("Ejercicio 2. Caso %d\n",caso);
        list<int> L;
        vector< list<int> > VL;
        int N = rnd.rand()%NN;
        for (int j=0; j<N; j++) L.push_back(rnd.rand()%MAX);
        int m = 2+rnd.rand()%3;
        F(L,m,VL);
        if (vrbs>=2) {
          printf("---------------- random case %d\n",caso);
          printf("L: "); prl(L); cout << endl;
          printf("VL: \n"); dump(VL);
        }
        hasher.hash(VL);
      }
      int H = hasher.val()%1000;
      if (vrbs) printf("EJ2 SEED=%03d, HASH=%03d\n",seed,H);
      return H;
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    int eval2r(interlaced_split_t Fuser,interlaced_split_t Fok,
               int seed,int vrbs=0) {
      int ncasos=20, NN=100, MAX=20;
      hasher_t hasher;
      randomg_t rnd;
      rnd.reset(seed);
      for (int caso=0; caso<ncasos; caso++) {
        if (vrbs>=2) printf("Ejercicio 2. Caso %d\n",caso);
        list<int> L1,L;
        vector< list<int> > VLuser,VLok;
        int N = rnd.rand()%NN;
        for (int j=0; j<N; j++) L.push_back(rnd.rand()%MAX);
        int m = 2+rnd.rand()%3;
        L1=L; VLuser.clear();
        Fuser(L1,m,VLuser);
        L1=L; VLok.clear();
        Fuser(L1,m,VLok);
        if (VLuser!=VLok) {
          printf("VLuser!=VLok\n");
          dump(VLuser);
          dump(VLok);

          exit(0);
        }
      }
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    typedef void (*interlaced_join_t)(vector< list<int> >&VL, list<int>&L);
    int verificar3(int &caso,int &okt,interlaced_join_t F,string svl, 
                   string sl,int vrbs=0) {
      vector< list<int> > VL,VLuser;
      list<int> Luser,Lans;
      s2vl(svl,VL);
      s2l(sl,Lans);
      VLuser = VL;
      F(VLuser,Luser);

      if (vrbs) {
        cout << "--------------" << endl << "Evaluando EJ3. Caso " 
             << caso << endl;
        dump(VL,"VL");
        cout << "Respuesta esperada: ";
        prl(Lans);
        cout << endl;
      }
      int ok = (Luser == Lans);
      cout << "EJ3|Caso" << caso << ". Estado: " << i2s(ok) << endl;
      if (!ok) {
        cout << "Respuesta incorrecta, L: ";
        prl(Luser);
        cout << endl;
      }
      if (vrbs) cout << "--------------" << endl;
      okt += ok; caso++;
    }

    //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
    void eval3(interlaced_join_t F,int vrbs=0) {
      cout << "----------------\nEvaluando ejercicio 3" << endl;
      int caso = 0, ok = 0;
      verificar3(caso,ok,F,"4 0 2 4 6 3 1 3 5","0 1 2 3 4 5 6",vrbs);
      verificar3(caso,ok,F,"3 0 3 6 2 1 4 2 2 5","0 1 2 3 4 5 6",vrbs);
      verificar3(caso,ok,F,"3 0 4 8 2 1 5 2 2 6 2 3 7","0 1 2 3 4 5 6 7 8",vrbs);
      verificar3(caso,ok,F,"2 0 1 1 2 2 3 4 2 5 6 1 7","0 2 3 5 7 1 4 6",vrbs);
      int total = caso;
      printf("ESTADO EJ3: total %d, ok %d, mal %d. Todos bien? %s\n",
             total,ok,total-ok,i2s(ok==total));

    }

    int eval3r(interlaced_join_t F,
                    int seed,int vrbs=0) {
      int ncasos=10, M=5, NN=100, MAX=50;
      // int ncasos=2, M=2, NN=4, MAX=10;
      hasher_t hasher;
      randomg_t rnd;
      rnd.reset(seed);
      for (int caso=0; caso<ncasos; caso++) {
        if (vrbs>=2) printf("Ejercicio 3. Caso %d\n",caso);
        int NL = M+rnd.rand()%M;
        list<int> L;
        vector< list<int> > VL(NL), VLuser;
        for (int j=0; j<NL; j++) {
          int N = NN+rnd.rand()%NN;
          list<int> &L = VL[j];
          for (int j=0; j<N; j++) L.push_back(rnd.rand()%MAX);
        }
        VLuser = VL;
        F(VLuser,L);
        if (vrbs>=2) {
          printf("---------------- random case %d\n",caso);
          printf("VL: \n"); dump(VL);
          printf("L: "); prl(L); cout << endl;
        }
        hasher.hash(L);
      }
      int H = hasher.val()%1000;
      if (vrbs) printf("EJ3 SEED=%03d, HASH=%03d\n",seed,H);
      return H;
    }

    void eval3r(interlaced_join_t Fuser,interlaced_join_t Fok,
                    int seed,int vrbs=0) {
      int ncasos=100, M=2, NN=4, MAX=10;
      hasher_t hasher;
      randomg_t rnd;
      rnd.reset(seed);
      for (int caso=0; caso<ncasos; caso++) {
        if (vrbs>=2) printf("Ejercicio 3. Caso %d\n",caso);
        int NL = M+rnd.rand()%M;
        list<int> Luser,Lok;
        vector< list<int> > VL(NL), VLuser;
        for (int j=0; j<NL; j++) {
          int N = NN+rnd.rand()%NN;
          list<int> &L = VL[j];
          for (int j=0; j<N; j++) L.push_back(rnd.rand()%MAX);
        }
        VLuser = VL;
        Fuser(VLuser,Luser);
        VLuser = VL;
        Fok(VLuser,Lok);
        if (Luser!=Lok) {
          printf("-----------------------------------------------\n");
          printf("VL\n");
          dump(VL);
          printf("Luser\n");
          dump(Luser);
          printf("Lok\n");
          dump(Lok);
        }
      }
    }
  };
}

#endif
