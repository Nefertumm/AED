#ifndef EVALUAR_HPP
#define EVALUAR_HPP
#include <string>
#include <map>
#include <list>
#include <vector>
#include <sstream>

#include "tree.h"

using namespace std;
using namespace aed;

namespace aed {
  class Evaluar
  {
    void printmap(map<int, list<bool> >& M) {
      cout << "M = {";
      map<int, list<bool> >::iterator p = M.begin();
      while (p!=M.end()) {
        cout << p->first << "->[";
        list<bool> &L = p->second;
        list<bool>::iterator q = L.begin();
        while (q!=L.end()) {
          cout << (*q ? "true" : "false");
          q++;
          if (q!=L.end()) cout << ", ";
        }
        cout << "]";
        p++;
        if (p!=M.end()) cout << ", ";
      }
      cout << "}" << endl;
    }

    list< list<int> > colas(list<int> &L) {
      list< list<int> > R;
      if (L.empty()) return R;
      list<int>::iterator it = L.begin();
      while (it != L.end()) {
        R.push_back(list<int>(it, L.end()));
        ++ it;
      }
      return R;
    }

    void s2l(string s, list<int> &L) {
      istringstream is(s);
      int n;
      while (is >> n) L.push_back(n);
    }

    void prl(list<int> &L) {
      if (L.empty()) return;
      list<int>::iterator il = L.begin();
      for (; &*il != &*L.rbegin(); il ++)
        cout << *il << " ";
      cout << *il;
    }

    void s2m(string s, map<int, list<bool> > &M) {
      M.clear();
      istringstream is(s);

      int k, n, v;
      while (is >> k >> n) {
        list<bool> L;

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          L.push_back(v);
        }
        M[k] = L;
      }
    }

    void s2m(string s, map<int, list<int> > &M) {
      M.clear();
      istringstream is(s);

      int k, n, v;
      while (is >> k >> n) {
        list<int> L;

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          L.push_back(v);
        }
        M[k] = L;
      }
    }

    void s2m(string s, map<int,int> &M) {
      M.clear();
      istringstream is(s);
      int k, n, v;
      while (is >> k >> n) {
        M[k] = n;
      }
    }

    void acum_hasta(list<int> &L, int n) {
      int acum = 0;
      list<int>::iterator it = L.begin();
      while (it != L.end()) {
        acum += *it;
        it = L.erase(it);
        if (acum >= n)
          {
            L.insert(it, acum);
            acum = 0;
          }
      }
      if (acum > 0)
        L.push_back(acum);
    }

    int readnum(string &s, unsigned int &n) {
      int k = 0;
      bool negativo = false;
      if (s[n] == '-') {
        negativo = true;
        n ++;
      }

      while (s[n] >= '0' && s[n] <= '9') {
        k *= 10;
        k += s[n] - '0';
        ++ n;
      }

      if (negativo) k *= -1;

      return k;
    }

    void lisp2tree(string s, tree<int> &T, unsigned int &i, 
                   tree<int>::iterator it) {
      while (i < s.size()) {
        while (s[i] == ' ') ++ i;

        if (s[i] == '(') {
          ++ i;
          while (s[i] == ' ') ++ i;
          it = T.insert(it, readnum(s, i));
          lisp2tree(s, T, i, it.lchild());
          ++ it;
        }
        else if (s[i] == ')') {
          ++ i;
          return;
        }
        else {
          it = T.insert(it, readnum(s, i));
          ++ it;
        }
      }
    }

    void lisp2tree(string s, tree<int> &T) {
      unsigned int i = 0;
      lisp2tree(s, T, i, T.begin());
    }

  public:

    typedef int (*evpath_t) (tree<int>&);
    void evaluar1(evpath_t F) {
      cout << endl << "Evaluando ejercicio 1" << endl;
      int OK=0,TOT=0;
      verificar1(F, "(0 (2 3 4 5) (6 (7 8 9)))", 2,OK,TOT);
      verificar1(F, "(1 (2 3 4 5) (6 (7 8 9)))", 0,OK,TOT);
      verificar1(F, "(0 (2 3 4 5) (6 (4 8 9)))", 3,OK,TOT);
      verificar1(F, "(0 (2 3 4 5) (6 (4 8 (2 10))))",4,OK,TOT);
      cout << "EJERCICIO 1: Nro de tests " << TOT << ", OK " << OK << endl;
    }

    void verificar1(evpath_t F, string t, int r,int &OK, int&TOT) {
      tree<int> T;
      lisp2tree(t, T);
      int ok1 = (F(T) == r);
      OK += ok1;
      TOT++;
      cout << "Test " << TOT << ", estado: "
           << (ok1? "BIEN" : "MAL") << endl;
    }

    typedef map<int,list<int> > graph_t;
    typedef bool (*checksz_t)(graph_t &G1,graph_t &G2);

    void evaluar2(checksz_t F) {
      cout << endl << "Evaluando ejercicio 2" << endl;
      int OK=0,TOT=0;
      verificar2(F, 
                 "1 2 2 4 2 3 1 3 4", 
                 "1 2 3 4 2 3 5 6 7", 
                 true,OK,TOT);
      verificar2(F, 
                 "1 2 2 4 2 3 1 3 4 7 1 1", 
                 "1 2 3 4 2 3 5 6 7", 
                 false,OK,TOT);
      verificar2(F, 
                 "1 2 2 4 2 3 1 3 4", 
                 "1 2 3 4 2 3 5 6 7 7 1 1", 
                 false,OK,TOT);
      verificar2(F, 
                 "1 2 2 4 2 3 1 3 4", 
                 "1 2 3 4 2 4 5 6 7 8",
                 false,OK,TOT);
      verificar2(F, 
                 "1 2 2 4 2 3 1 3 4 5 2 6 7", 
                 "1 2 3 4 2 3 5 6 7 5 2 9 10",
                 true,OK,TOT);
      cout << "EJERCICIO 2: Nro de tests " << TOT << ", OK " << OK << endl;
    }
    
    void verificar2(checksz_t F, 
                    string m1, string m2, bool r,
                    int &OK, int&TOT)     {
      map<int, list<int> > M1, M2;
      s2m(m1, M1);
      s2m(m2, M2);
      int ok1 = (F(M1, M2)==r);
      OK += ok1;
      TOT++;
      cout << "Test " << TOT << ", estado: "
           << (ok1? "BIEN" : "MAL") << endl;
    }

    typedef void (*maxodd_t)(list<int> &L,map<int,int> &M);
    
    void evaluar3(maxodd_t F) {
      cout << endl << "Evaluando ejercicio 3" << endl;
      int OK=0,TOT=0;
      verificar3(F,"1 2 4 3 2 5 2 7 1 6 9 2 14", 
                   "2 7 4 3 6 9",OK,TOT);

      verificar3(F,"5 10 2 6 10 1 8 9 6 2 2 10", 
                   "10 1 8 9",OK,TOT);

      verificar3(F,"5 10 7 9 10 8 10 4 7 1 5 4", 
                   "4 7 10 9",OK,TOT);

      verificar3(F,"7 8 9 10 6 1 1 3 4 4 6 2", 
                   "6 3 8 9",OK,TOT);

      cout << "EJERCICIO 3: Nro de tests " << TOT << ", OK " << OK << endl;
    }
	
    void verificar3(maxodd_t F,string l,string m,
                    int &OK, int&TOT) {
      list<int> L;
      s2l(l, L);
      map<int,int> M, R;
      s2m(m, M);
      F(L, R);
      int ok1 = (R == M);
      OK += ok1;
      TOT++;
      cout << "Test " << TOT << ", estado: "
           << (ok1? "BIEN" : "MAL") << endl;
    }
  };

}

#endif
