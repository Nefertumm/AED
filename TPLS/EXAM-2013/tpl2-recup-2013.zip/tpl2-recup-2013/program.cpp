#include <cstdio>

#include "Evaluar.hpp"
#include "./tree.h"
#include "./util_tree.h"
#include "./util.h"


typedef tree<int> tree_t;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int evpath(tree_t &T,tree_t::iterator n) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int evpath(tree_t &T) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
typedef map<int,list<int> > graph_t;
typedef map<int,int> mapsz_t;

bool checksz(graph_t &G1,graph_t &G2) {
  // printmap(G1);
  // printmap(G2);
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void maxodd(list<int> &L,map<int,int> &M) {
  // COMPLETAR...
}

using namespace aed;
int main() {
  Evaluar ev;
  ev.evaluar1(evpath);
  ev.evaluar2(checksz);
  ev.evaluar3(maxodd);
  return 0;
}
