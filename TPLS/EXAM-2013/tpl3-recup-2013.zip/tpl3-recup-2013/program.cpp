#include <set>
#include <vector>
#include <list>
#include <cstdio>

#include "Evaluar.hpp"
#include "util.h"
#include "btree.h"
#include "util_btree.h"

using namespace std;
using namespace aed;

typedef list< set<int> > ls_t;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void subsup(ls_t &LS,set<int> &W,ls_t &LSUB,ls_t &LSUP) {
  // COMPLETAR...
}
    
bool inall(ls_t &LS,set<int> &S) {
  // COMPLETAR...
  return true;
}

typedef btree<int> AB_t;
typedef AB_t::iterator node_t;
bool sum_sim(AB_t &T1, AB_t &T2, int l) {
  // COMPLETAR...
  return true;
}

int main() {
  Evaluar ev;
  ev.evaluar1(subsup);
  ev.evaluar2(inall);
  ev.evaluar3(sum_sim,1);
  return 0;
}
