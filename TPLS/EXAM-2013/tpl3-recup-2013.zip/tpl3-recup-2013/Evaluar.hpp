#ifndef EVALUAR_HPP
#define EVALUAR_HPP
#include <string>
#include <map>
#include <list>
#include <vector>
#include <sstream>

#include "btree.h"

using namespace std;
using namespace aed;

namespace aed {
  class Evaluar {

    void printmap(map<int, list<bool> >& M) {
      cout << "M = {";
      map<int, list<bool> >::iterator p = M.begin();
      while (p!=M.end()) {
        cout << p->first << "->[";
        list<bool> &L = p->second;
        list<bool>::iterator q = L.begin();
        while (q!=L.end()) {
          cout << (*q ? "true" : "false");
          q++;
          if (q!=L.end()) cout << ", ";
        }
        cout << "]";
        p++;
        if (p!=M.end()) cout << ", ";
      }
      cout << "}" << endl;
    }

    list< list<int> > colas(list<int> &L) {
      list< list<int> > R;
      if (L.empty()) return R;
      list<int>::iterator it = L.begin();
      while (it != L.end()) {
        R.push_back(list<int>(it, L.end()));
        ++ it;
      }
      return R;
    }

    void s2l(string s, list<int> &L) {
      istringstream is(s);
      int n;
      while (is >> n) L.push_back(n);
    }

    void s2s(string s, set<int> &L) {
      istringstream is(s);
      int n;
      while (is >> n) L.insert(n);
    }    

    void prl(list<int> &L) {
      if (L.empty()) return;
      list<int>::iterator il = L.begin();
      for (; &*il != &*L.rbegin(); il ++)
        cout << *il << " ";
      cout << *il;
    }

    void s2m(string s, map<int, list<bool> > &M) {
      M.clear();
      istringstream is(s);

      int k, n, v;
      while (is >> k >> n) {
        list<bool> L;

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          L.push_back(v);
        }
        M[k] = L;
      }
    }

    void s2m(string s, map<int, list<int> > &M) {
      M.clear();
      istringstream is(s);

      int k, n, v;
      while (is >> k >> n) {
        list<int> L;

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          L.push_back(v);
        }
        M[k] = L;
      }
    }

    void s2ls(string s, list< set<int> > &M) { // string to list<set>
      M.clear();
      istringstream is(s);

      int n, v;
      while (is >> n) {
        M.push_back(set<int>());

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          M.back().insert(v);
        }
      }
    }    

    void s2vs(string s, vector< set<int> > &M) { // string to vector<set>
      M.clear();
      istringstream is(s);

      int n, v;
      while (is >> n) {
        M.push_back(set<int>());

        for (int i = 0 ; i < n ; i ++) {
          is >> v;
          M.back().insert(v);
        }
      }
    }        

    void s2m(string s, map<int,int> &M) {
      M.clear();
      istringstream is(s);
      int k, n, v;
      while (is >> k >> n) {
        M[k] = n;
      }
    }

    void acum_hasta(list<int> &L, int n) {
      int acum = 0;
      list<int>::iterator it = L.begin();
      while (it != L.end()) {
        acum += *it;
        it = L.erase(it);
        if (acum >= n)
          {
            L.insert(it, acum);
            acum = 0;
          }
      }
      if (acum > 0)
        L.push_back(acum);
    }

    int readnum(string &s, unsigned int &n) {
      int k = 0;
      bool negativo = false;
      if (s[n] == '-') {
        negativo = true;
        n ++;
      }

      while (s[n] >= '0' && s[n] <= '9') {
        k *= 10;
        k += s[n] - '0';
        ++ n;
      }

      if (negativo) k *= -1;

      return k;
    }

    void lisp2btree(string s, btree<int> &T, unsigned int &i, 
                    btree<int>::iterator it) {
      while (i < s.size())
        {
          while (s[i] == ' ') ++ i;

          if (s[i] == '(')
            {
              ++ i;
              it = T.insert(it, readnum(s, i));

              lisp2btree(s, T, i, it.left());
              lisp2btree(s, T, i, it.right());
            }
          else if (s[i] == ')' || s[i] == '.')
            {
              ++ i;
              return;
            }
          else
            {
              T.insert(it, readnum(s, i));
              return;
            }
        }
    }

    void lisp2btree(string s, btree<int> &T) {
      unsigned int i = 0;
      lisp2btree(s, T, i, T.begin());
    }
  public:

    const char* okbm(int ok) { return ok? "BIEN" : "MAL"; }
    const char* oksn(int ok) { return ok? "SI" : "NO"; }
    
    typedef list< set<int> > ls_t;
    typedef void (*subsup_t)(ls_t &LS,set<int> &W,ls_t &LSUB,ls_t &LSUP);
      
    void evaluar1(subsup_t F,int vrbs=0) {
      cout << endl << "Evaluando ejercicio 1" << endl;
      int OK=0,TOT=0;
      verificar1(F,"2 1 2 1 2 3 2 3 4 3 2 4 6 3 1 3 5", 
                 "2 2 4", "1 2", "3 2 3 4 3 2 4 6",
                 OK, TOT,vrbs);
      verificar1(F,"0 2 1 2 1 2 3 2 3 4 3 2 4 6 3 1 3 5", 
                 "2 2 4", "0 1 2", "3 2 3 4 3 2 4 6",
                 OK, TOT,vrbs);
      verificar1(F,"2 1 2 1 2 3 2 3 4 3 2 4 6 3 1 3 5", 
                 "", "", "2 1 2 1 2 3 2 3 4 3 2 4 6 3 1 3 5",
                 OK, TOT,vrbs);

      // RANDOM GENERATED
#define AUTO1(s1,s2,s3,s4) verificar1(F,s1,s2,s3,s4,OK, TOT,vrbs)
      
      //================
      AUTO1("1 1 0 3 0 2 3 3 1 2 3 ", // LS
           "0 2 3 ", // W
           "0 3 0 2 3 ", // LSUB
           "3 0 2 3 "); // LSUP
      
      //================
      AUTO1("1 3 3 1 2 3 0 1 3 ", // LS
           "", // W
           "0 ", // LSUB
           "1 3 3 1 2 3 0 1 3 "); // LSUP

      //================
      AUTO1("1 2 3 0 1 3 1 1 1 3 4 0 1 2 3 ", // LS
           "", // W
           "", // LSUB
           "1 2 3 0 1 3 1 1 1 3 4 0 1 2 3 "); // LSUP
      
      //================
      AUTO1("1 3 0 1 1 2 0 2 1 1 ", // LS
           "", // W
           "0 ", // LSUB
           "1 3 0 1 1 2 0 2 1 1 "); // LSUP
      //================
      AUTO1("2 0 1 1 1 3 0 1 3 2 1 2 2 0 2 ", // LS
           "0 2 3 ", // W
           "2 0 2 ", // LSUB
           ""); // LSUP
      //================
      AUTO1("2 0 3 1 2 1 0 ", // LS
           "0 2 ", // W
           "1 2 1 0 ", // LSUB
           ""); // LSUP
      //================
      AUTO1("0 0 3 1 2 3 2 0 1 2 0 1 ", // LS
           "", // W
           "0 0 ", // LSUB
           "0 0 3 1 2 3 2 0 1 2 0 1 "); // LSUP
      //================
      AUTO1("1 1 3 0 1 3 1 1 2 1 3 0 ", // LS
           "0 1 3 ", // W
           "1 1 3 0 1 3 1 1 2 1 3 0 ", // LSUB
           "3 0 1 3 "); // LSUP
      //================
      AUTO1("1 1 1 3 2 0 3 ", // LS
           "0 2 3 ", // W
           "1 3 2 0 3 ", // LSUB
           ""); // LSUP
      //================
      AUTO1("0 0 4 0 1 2 3 1 3 ", // LS
           "3 ", // W
           "0 0 1 3 ", // LSUB
           "4 0 1 2 3 1 3 "); // LSUP

      cout << "EJERCICIO 1: Nro de tests " << TOT 
           << ", OK " << OK 
           << ".\n[EJ1] TODO OK? " << oksn(OK==TOT) << endl;
    }

    void verificar1(subsup_t F, string LSs, string Ws,
                    string LSUBs, string LSUPs,
                    int &OK, int&TOT,int vrbs) {
      // suffix s = stringified object
      // suffix u = user returned value
      ls_t LS,LSUB,LSUP,LSUBu,LSUPu;
      set<int> W;
      s2ls(LSs, LS);
      s2s(Ws, W);
      s2ls(LSUBs, LSUB);
      s2ls(LSUPs, LSUP);
      F(LS,W,LSUBu,LSUPu);
      int ok1 = (LSUBu==LSUB && LSUPu==LSUP);
      if (vrbs) {
        printf("\n================\nLS: \n"); print(LS); printf("\n\n");
        printf("W: "); print(W); printf("\n\n");
        printf("LSUB(user):\n"); print(LSUBu); printf("\n\n");
        printf("LSUB(ref):\n"); print(LSUB); printf("\n\n");
        printf("LSUP(user):\n"); print(LSUPu); printf("\n\n");
        printf("LSUP(ref):\n"); print(LSUP); printf("\n\n");
      }
      OK += ok1;
      TOT++;
      cout << "Test " << TOT << ", estado: "
           << okbm(ok1) << endl;
    }
    
    typedef bool (*inall_t) (ls_t &LS,set<int> &S);

    void verificar2(inall_t F, string LSs, string Ss,int retval,
                    int &OK, int&TOT,int vrbs) {
      // suffix s = stringified object
      // suffix u = user returned value
      ls_t LS;
      set<int> S,Su;
      s2ls(LSs, LS);
      s2s(Ss, S);
      bool rvuser = F(LS,Su);
      int ok1 = (rvuser==retval);
      if (retval) ok1 &= (Su==S);
      if (vrbs) {
        printf("\n================\nLS: \n"); print(LS); printf("\n\n");
        printf("S(user): "); print(Su); printf(", rv: %d\n\n",rvuser);
        printf("S(ref): "); print(S); printf(", rv: %d\n\n",retval);
      }
      OK += ok1;
      TOT++;
      cout << "Test " << TOT << ", estado: "
           << okbm(ok1) << endl;
    }

    void evaluar2(inall_t F,int vrbs=0) {
      cout << endl << "Evaluando ejercicio 2" << endl;
      int OK=0,TOT=0;
      verificar2(F,"3 1 2 3 3 2 3 4","",0,
                 OK, TOT,vrbs);
      verificar2(F,"3 1 2 3 4 1 2 3 4 3 1 2 3","3 1 2 3",1,
                 OK, TOT,vrbs);
      verificar2(F,"3 1 2 3 1 1 2 1 2","1 1",1,
                 OK, TOT,vrbs);
#define AUTO2(s1,s2,v) verificar2(F,s1,s2,v,OK, TOT,vrbs)
      //================
      AUTO2("1 2 2 2 3 3 1 2 3 3 0 1 2 ", // LS
            "2 ", // S
            1); // retval
      //================
      AUTO2("4 0 1 2 3 3 1 2 3 3 1 2 3 4 0 1 2 3 ", // LS
            "1 2 3 ", // S
            1); // retval
      //================
      AUTO2("3 1 2 3 4 0 1 2 3 3 1 2 3 ", // LS
            "1 2 3 ", // S
            1); // retval
      //================
      AUTO2("3 0 1 2 4 0 1 2 3 3 0 1 3 1 1 3 1 2 3 ", // LS
            "1 ", // S
            1); // retval
      //================
      AUTO2("3 0 2 3 3 0 2 3 3 0 2 3 ", // LS
            "0 2 3 ", // S
            1); // retval
      //================
      AUTO2("2 2 3 3 1 2 3 3 0 1 2 ", // LS
            "2 3 ", // S
            0); // retval
      //================
      AUTO2("3 0 1 2 3 0 1 3 2 1 3 3 0 1 3 ", // LS
            "1 3 ", // S
            0); // retval
      //================
      AUTO2("3 0 2 3 3 0 1 3 3 0 2 3 4 0 1 2 3 ", // LS
            "0 2 3 ", // S
            0); // retval
      //================
      AUTO2("3 0 1 3 3 0 1 2 ", // LS
            "0 1 3 ", // S
            0); // retval
      //================
      AUTO2("3 0 2 3 3 0 1 3 3 0 1 3 ", // LS
            "0 2 3 ", // S
            0); // retval

      cout << "EJERCICIO 2: Nro de tests " << TOT 
           << ", OK " << OK 
           << ".\n[EJ2] TODO OK? " << oksn(OK==TOT) << endl;
    }

    typedef btree<int> AB_t;
    typedef AB_t::iterator node_t;
    typedef bool (*sum_sim_t)(AB_t &T1, AB_t &T2, int l);
    void evaluar3(sum_sim_t F,int vrbs=0) {
      cout << endl << "Evaluando ejercicio 2" << endl;
      int OK=0,TOT=0;
      verificar3(F,"(3 (9 5 (9 . 9)) 7)", // A
                 "(3 7 (9 (9 9 .) 5))", // B
                 3,1, // l, retval
                 OK,TOT,vrbs);

#define AUTO3(sa,sb,l,rv) verificar3(F,sa,sb,l,rv,OK,TOT,vrbs)

      AUTO3("(3 (7 3 9) (0 (3 (0 2 .) .) 2))", // A
            "(3 (5 (2 8 .) (1 (9 (1 (4 . (4 . 3)) .) 3) .)) (5 (4 6 3) .))", // B
            0,1); // l, retval
      AUTO3("(3 (7 3 9) (0 (3 (0 2 .) .) 2))", // A
            "(3 (5 (2 8 .) (1 (9 (1 (4 . (4 . 3)) .) 3) .)) (5 (4 6 3) .))", // B
            1,0); // l, retval
      AUTO3("(3 (7 3 9) (0 (3 (0 2 .) .) 2))", // A
            "(3 (5 (2 8 .) (1 (9 (1 (4 . (4 . 3)) .) 3) .)) (5 (4 6 3) .))", // B
            2,0); // l, retval
      AUTO3("(3 (7 3 9) (0 (3 (0 2 .) .) 2))", // A
            "(3 (5 (2 8 .) (1 (9 (1 (4 . (4 . 3)) .) 3) .)) (5 (4 6 3) .))", // B
            3,0); // l, retval
      AUTO3("(3 (7 3 9) (0 (3 (0 2 .) .) 2))", // A
            "(3 (5 (2 8 .) (1 (9 (1 (4 . (4 . 3)) .) 3) .)) (5 (4 6 3) .))", // B
            4,0); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            0,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            1,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            2,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            3,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            4,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            5,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            6,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            7,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            8,1); // l, retval
      AUTO3("(2 (4 (4 (3 . (8 . 8)) (4 2 (9 (6 (4 (5 . (8 . 7)) .) 6) .))) .) (9 . 0))", // A
            "(2 (9 0 .) (4 . (4 (4 (9 . (6 6 (4 . (5 (8 7 .) .)))) 2) (3 (8 8 .) .))))", // B
            9,1); // l, retval
      AUTO3("(7 (1 (5 7 .) .) (5 . (9 (8 2 .) (8 . (0 6 .)))))", // A
            "(6 (1 (9 (4 . (0 (0 (4 (4 . 3) .) 6) .)) .) (7 . (8 (9 5 (3 (8 (6 . 3) .) 4)) .))) (7 6 .))", // B
            0,0); // l, retval
      AUTO3("(7 (1 (5 7 .) .) (5 . (9 (8 2 .) (8 . (0 6 .)))))", // A
            "(6 (1 (9 (4 . (0 (0 (4 (4 . 3) .) 6) .)) .) (7 . (8 (9 5 (3 (8 (6 . 3) .) 4)) .))) (7 6 .))", // B
            1,0); // l, retval
      AUTO3("(7 (1 (5 7 .) .) (5 . (9 (8 2 .) (8 . (0 6 .)))))", // A
            "(6 (1 (9 (4 . (0 (0 (4 (4 . 3) .) 6) .)) .) (7 . (8 (9 5 (3 (8 (6 . 3) .) 4)) .))) (7 6 .))", // B
            2,0); // l, retval
      AUTO3("(7 (1 (5 7 .) .) (5 . (9 (8 2 .) (8 . (0 6 .)))))", // A
            "(6 (1 (9 (4 . (0 (0 (4 (4 . 3) .) 6) .)) .) (7 . (8 (9 5 (3 (8 (6 . 3) .) 4)) .))) (7 6 .))", // B
            3,0); // l, retval
      AUTO3("(7 (1 (5 7 .) .) (5 . (9 (8 2 .) (8 . (0 6 .)))))", // A
            "(6 (1 (9 (4 . (0 (0 (4 (4 . 3) .) 6) .)) .) (7 . (8 (9 5 (3 (8 (6 . 3) .) 4)) .))) (7 6 .))", // B
            4,0); // l, retval
      AUTO3("(7 (1 (5 7 .) .) (5 . (9 (8 2 .) (8 . (0 6 .)))))", // A
            "(6 (1 (9 (4 . (0 (0 (4 (4 . 3) .) 6) .)) .) (7 . (8 (9 5 (3 (8 (6 . 3) .) 4)) .))) (7 6 .))", // B
            5,0); // l, retval
      AUTO3("(3 (9 5 (9 . 9)) 7)", // A
            "(3 7 (9 (9 9 .) 5))", // B
            0,1); // l, retval
      AUTO3("(3 (9 5 (9 . 9)) 7)", // A
            "(3 7 (9 (9 9 .) 5))", // B
            1,1); // l, retval
      AUTO3("(3 (9 5 (9 . 9)) 7)", // A
            "(3 7 (9 (9 9 .) 5))", // B
            2,1); // l, retval
      AUTO3("(3 (9 5 (9 . 9)) 7)", // A
            "(3 7 (9 (9 9 .) 5))", // B
            3,1); // l, retval
      cout << "EJERCICIO 3: Nro de tests " << TOT 
           << ", OK " << OK 
           << ".\n[EJ3] TODO OK? " << oksn(OK==TOT) << endl;
    }
    
    void verificar3(sum_sim_t F, string As, string Bs,int l,int retval,
                    int &OK, int&TOT,int vrbs) {
      // suffix s = stringified object
      // suffix u = user returned value
      btree<int> A,B;
      lisp2btree(As,A);
      lisp2btree(Bs,B);
      int rvuser = F(A,B,l);
      int ok1 = (rvuser==retval);
      if (vrbs) {
        printf("\n================\n"); 
        printf("A: "); A.lisp_print(); printf("\n");
        printf("B: "); B.lisp_print(); printf("\n");
        printf("retval: user %d, ref %d\n\n",rvuser,retval);
      }
      OK += ok1;
      TOT++;
      cout << "Test " << TOT << ", estado: "
           << okbm(ok1) << endl;
    }      

    void print(set<int> &S) {
      cout << "{";
      set<int>::iterator q=S.begin();
      while (q!=S.end()) {
        cout << *q;
        q++;
        if (q!=S.end()) cout << ",";
      }
      cout << "}";
    }

    void print(ls_t &LS) {
      ls_t::iterator q = LS.begin();
      int j=0;
      while (q!=LS.end()) {
        set<int> &S = *q;
        cout << "S" << j++ << "=";
        print(S);
        cout << endl;
        q++;
      }
    }

    typedef vector< set<int> > vs_t;
    void print(vs_t &VS) {
      vs_t::iterator q = VS.begin();
      int j=0;
      while (q!=VS.end()) {
        set<int> &S = *q;
        cout << "S" << j;
        print(S);
        cout << endl;
        q++;
      }
    }

  };
}

#endif
