#include "Evaluar.hpp"

int main()
{
    aed::Evaluar ev;
    ev.evaluar1(mergekw);
    ev.evaluar2(split_list);
    ev.evaluar3(join_list);
    return 0;
}
