#ifndef EVALUAR_HPP
#define EVALUAR_HPP
#include <string>
#include <map>
#include <vector>
#include <list>
#include <iostream>
#include <sstream>
using namespace std;

namespace aed {
class Evaluar
{
	void printmap(map<int, list<bool> >& M) {
		cout << "M = {";
		map<int, list<bool> >::iterator p = M.begin();
		while (p!=M.end()) {
			cout << p->first << "->[";
			list<bool> &L = p->second;
			list<bool>::iterator q = L.begin();
			while (q!=L.end()) {
				cout << (*q ? "true" : "false");
				q++;
				if (q!=L.end()) cout << ", ";
			}
			cout << "]";
			p++;
			if (p!=M.end()) cout << ", ";
		}
		cout << "}" << endl;
	}

	list< list<int> > colas(list<int> &L)
	{
		list< list<int> > R;
		if (L.empty()) return R;
		list<int>::iterator it = L.begin();
		while (it != L.end())
		{
			R.push_back(list<int>(it, L.end()));
			++ it;
		}

		return R;
	}

	void s2l(string s, list<int> &L)
	{
		istringstream is(s);
		int n;
		while (is >> n)
			L.push_back(n);
	}

	void prl(list<int> &L)
	{
		if (L.empty()) return;
		list<int>::iterator il = L.begin();
		for (; &*il != &*L.rbegin(); il ++)
			cout << *il << " ";
		cout << *il;
	}

	void s2m(string s, map<int, list<bool> > &M)
	{
		M.clear();
		istringstream is(s);

		int k, n, v;
		while (is >> k >> n)
		{
			list<bool> L;

			for (int i = 0 ; i < n ; i ++)
			{
				is >> v;
				L.push_back(v);
			}
			M[k] = L;
		}
	}

	void s2m(string s, map<int, list<int> > &M)
	{
		M.clear();
		istringstream is(s);

		int k, n, v;
		while (is >> k >> n)
		{
			list<int> L;

			for (int i = 0 ; i < n ; i ++)
			{
				is >> v;
				L.push_back(v);
			}
			M[k] = L;
		}
	}

	void s2vl(string s, vector< list<int> > &v)
	{
		istringstream is(s);
		int n1, n2;
		while (is >> n1)
		{
			v.push_back(list<int>());
			for (int i = 0 ; i < n1 ; i ++)
			{
				is >> n2;
				v.back().push_back(n2);
			}
		}
	}

	void acum_hasta(list<int> &L, int n)
	{
		int acum = 0;
		list<int>::iterator it = L.begin();
		while (it != L.end())
		{
			acum += *it;
			it = L.erase(it);
			if (acum >= n)
			{
				L.insert(it, acum);
				acum = 0;
			}
		}
		if (acum > 0)
			L.push_back(acum);
	}

	public:

	void evaluar1(void (*F) (vector< list<int> >&, list<int>&))
	{
		cout << "Evaluando ejercicio 1" << endl;
		verificar1(F, "3 1 4 6 5 1 3 4 6 10 2 6 8", "1 1 3 4 4 6 6 6 8 10");
		verificar1(F, "3 1 2 3 3 2 3 4 3 3 4 5", "1 2 2 3 3 3 4 4 5");
		verificar1(F, "0 1 5 1 6 1 3 0", "3 5 6");
		verificar1(F, "0 0 0 0 0 0 1 1 0 0 0", "1");
		verificar1(F, "2 1 2 3 0 0 0", "0 0 0 1 2");
		verificar1(F, "1 1 1 2 1 3 1 4 1 5 1 6", "1 2 3 4 5 6");
		verificar1(F, "3 1 2 3 1 1 5 5 6 7 8 9", "1 1 2 3 5 6 7 8 9");
		verificar1(F, "1 1 1 1 1 1", "1 1 1");
	}

	void verificar1(void (*F) (vector< list<int> >&, list<int>&), string s1, string s2)
	{
		vector< list<int> > v;
		list<int> L1, L2;
		s2vl(s1, v);
		s2l(s2, L1);
		F(v, L2);
		/*
		for (int i = 0 ; i < v.size() ; i ++)
		{
			//cout << "v[" << i << "] = ";

			cout << v[i].size() << " ";
			prl(v[i]);
			cout << " ";
		}
		cout << endl;
		cout << endl;
		*/

		if (L1 == L2)
			cout << "BIEN" << endl;
		else
			cout << "NO" << endl;
	}

	void evaluar2(void (*F) (vector< list<int> >&, int, vector< list<int> >&))
	{
		cout << "Evaluando ejercicio 2" << endl;
		verificar2(F, "4 4 6 8 10 1 1 6 1 2 3 4 5 6", 3, "3 4 6 8 1 10 1 1 3 1 2 3 3 4 5 6");
		verificar2(F, "1 1 2 1 2 3 1 2 3 4 1 2 3 4 5 1 2 3 4 5", 2, "1 1 2 1 2 2 1 2 1 3 2 1 2 2 3 4 2 1 2 2 3 4 1 5");
		verificar2(F, "3 1 2 3 3 1 2 3 3 1 2 3", 3, "3 1 2 3 3 1 2 3 3 1 2 3");
		verificar2(F, "2 1 2 3 1 2 3", 1, "1 1 1 2 1 1 1 2 1 3");
	}

	void verificar2(void (*F) (vector< list<int> >&, int, vector< list<int> >&), string s1, int m, string s2)
	{
		vector< list<int> > v1, v2, v3;
		s2vl(s1, v1);
		s2vl(s2, v2);
		F(v1, m, v3);
		if (v2 == v3)
			cout << "BIEN" << endl;
		else
			cout << "NO" << endl;
	}

	void evaluar3(void (*F) (vector< list<int> >&, int, vector< list<int> >&))
	{
		cout << "Evaluando ejercicio 3" << endl;
		verificar3(F, "3 2 4 10 3 4 8 5 3 7 5 7 2 2 9 3 1 7 5 3 3 8 5 3 6 3 10 3 3 8 4 1 2", 5, "6 2 4 10 4 8 5 5 7 5 7 2 9 6 1 7 5 3 8 5 6 6 3 10 3 8 4 1 2");
		verificar3(F, "2 1 2 1 1 3 1 2 3 4 1 2 3 4", 3, "3 1 2 1 3 1 2 3 4 1 2 3 4");
		verificar3(F, "2 1 2 2 3 4", 3, "4 1 2 3 4");
		verificar3(F, "1 1 1 2 1 3 1 4 1 5 1 6", 20, "6 1 2 3 4 5 6");
		verificar3(F, "3 1 2 3 3 1 2 3 3 1 2 3", 1, "3 1 2 3 3 1 2 3 3 1 2 3");
	}

	void verificar3(void (*F) (vector< list<int> >&, int, vector< list<int> >&), string s1, int m, string s2)
	{
		vector< list<int> > v1, v2, v3;
		s2vl(s1, v1);
		s2vl(s2, v2);
		F(v1, m, v3);
		if (v2 == v3)
			cout << "BIEN" << endl;
		else
			cout << "NO" << endl;
	}
};

}

#endif


