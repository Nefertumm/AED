#include "Evaluar.hpp"

void split_mod(list<int>&L, int m,
               vector< list<int> >&VL) {
  // LLENAR AQUI...
}

bool is_sublist(list<int>&L1, list<int>&L2) {
  // LLENAR AQUI...
}

void max_sublist(list<int>&L, list<int>&subl) {
  // LLENAR AQUI...
}

int main() {
  aed::Evaluar ev;
  ev.evaluar1(split_mod);
  ev.evaluar2(is_sublist);
  ev.evaluar3(max_sublist);
  return 0;
}
