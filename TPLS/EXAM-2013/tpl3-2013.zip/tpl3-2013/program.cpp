#include <set>
#include <vector>
#include <list>
#include <cstdio>

#include "Evaluar.hpp"
#include "util.h"
#include "btree.h"

using namespace std;
using namespace aed;

typedef list< set<int> > ls_t;
void gatherset(ls_t &S,ls_t &W) {
  // cout << "S: " << endl;  print(S);
  // COMPLETAR.... (definir W)
  // cout << "W: " << endl;  print(W);
}

typedef list< set<int> > ls_t;
typedef vector< set<int> > vs_t;
set<int> maxshare(vs_t &S,set<int> &W) {
  // cout << "S: " << endl;  print(S);
  // cout << "W: ";  print(W); cout << endl;
  set<int> Smax;
  // COMPLETAR.... (definir Smax)
  // cout << "Smax: ";  print(Smax); cout << endl;
  return Smax;
}

typedef btree<int> tree_t;
typedef btree<int>::iterator node_t;
int sccount(tree_t &T, node_t n) {
  // COMPLETAR.... 
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Wrapper
int sccount(tree_t &T) {
  cout << "T:"; T.lisp_print();
  // COMPLETAR.... 
  cout << "\nsccount(T): " << r << endl;
  return r;
}

int main() {
  Evaluar ev;
  ev.evaluar1(gatherset);
  ev.evaluar2(maxshare);
  ev.evaluar3(sccount);
  return 0;
}
