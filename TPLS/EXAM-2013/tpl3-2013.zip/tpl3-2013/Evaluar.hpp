#ifndef EVALUAR_HPP
#define EVALUAR_HPP
#include <string>
#include <map>
#include <list>
#include <vector>
#include <sstream>

#include "btree.h"

using namespace std;
using namespace aed;

namespace aed {
class Evaluar
{
	void printmap(map<int, list<bool> >& M) {
		cout << "M = {";
		map<int, list<bool> >::iterator p = M.begin();
		while (p!=M.end()) {
			cout << p->first << "->[";
			list<bool> &L = p->second;
			list<bool>::iterator q = L.begin();
			while (q!=L.end()) {
				cout << (*q ? "true" : "false");
				q++;
				if (q!=L.end()) cout << ", ";
			}
			cout << "]";
			p++;
			if (p!=M.end()) cout << ", ";
		}
		cout << "}" << endl;
	}

	list< list<int> > colas(list<int> &L) {
		list< list<int> > R;
		if (L.empty()) return R;
		list<int>::iterator it = L.begin();
		while (it != L.end()) {
			R.push_back(list<int>(it, L.end()));
			++ it;
		}
		return R;
	}

	void s2l(string s, list<int> &L) {
		istringstream is(s);
		int n;
		while (is >> n) L.push_back(n);
	}

	void s2s(string s, set<int> &L) {
		istringstream is(s);
		int n;
		while (is >> n) L.insert(n);
	}    


	void prl(list<int> &L) {
		if (L.empty()) return;
		list<int>::iterator il = L.begin();
		for (; &*il != &*L.rbegin(); il ++)
			cout << *il << " ";
		cout << *il;
	}

	void s2m(string s, map<int, list<bool> > &M) {
		M.clear();
		istringstream is(s);

		int k, n, v;
		while (is >> k >> n) {
			list<bool> L;

			for (int i = 0 ; i < n ; i ++) {
				is >> v;
				L.push_back(v);
			}
			M[k] = L;
		}
	}

	void s2m(string s, map<int, list<int> > &M) {
		M.clear();
		istringstream is(s);

		int k, n, v;
		while (is >> k >> n) {
			list<int> L;

			for (int i = 0 ; i < n ; i ++) {
				is >> v;
				L.push_back(v);
			}
			M[k] = L;
		}
	}

	void s2ls(string s, list< set<int> > &M) { // string to list<set>
		M.clear();
		istringstream is(s);

		int n, v;
		while (is >> n) {
			M.push_back(set<int>());

			for (int i = 0 ; i < n ; i ++) {
				is >> v;
				M.back().insert(v);
			}
		}
	}    

	void s2vs(string s, vector< set<int> > &M) { // string to vector<set>
		M.clear();
		istringstream is(s);

		int n, v;
		while (is >> n) {
			M.push_back(set<int>());

			for (int i = 0 ; i < n ; i ++) {
				is >> v;
				M.back().insert(v);
			}
		}
	}        

	void s2m(string s, map<int,int> &M) {
		M.clear();
		istringstream is(s);
		int k, n, v;
		while (is >> k >> n) {
			M[k] = n;
		}
	}

	void acum_hasta(list<int> &L, int n) {
		int acum = 0;
		list<int>::iterator it = L.begin();
		while (it != L.end()) {
			acum += *it;
			it = L.erase(it);
			if (acum >= n)
			{
				L.insert(it, acum);
				acum = 0;
			}
		}
		if (acum > 0)
			L.push_back(acum);
	}

	int readnum(string &s, unsigned int &n) {
		int k = 0;
		bool negativo = false;
		if (s[n] == '-') {
			negativo = true;
			n ++;
		}

		while (s[n] >= '0' && s[n] <= '9') {
			k *= 10;
			k += s[n] - '0';
			++ n;
		}

		if (negativo) k *= -1;

		return k;
	}


	void lisp2btree(string s, btree<int> &T, unsigned int &i, btree<int>::iterator it)
	{
		while (i < s.size())
		{
			while (s[i] == ' ') ++ i;

			if (s[i] == '(')
			{
				++ i;
				it = T.insert(it, readnum(s, i));

				lisp2btree(s, T, i, it.left());
				lisp2btree(s, T, i, it.right());
			}
			else if (s[i] == ')' || s[i] == '.')
			{
				++ i;
				return;
			}
			else
			{
				T.insert(it, readnum(s, i));
				return;
			}
		}
	}

	void lisp2btree(string s, btree<int> &T)
	{
		unsigned int i = 0;
		lisp2btree(s, T, i, T.begin());
	}
	public:

        const char* okbm(int ok) { return ok? "BIEN" : "MAL"; }
        const char* oksn(int ok) { return ok? "SI" : "NO"; }
  
	typedef void (*gatherset_t) (list< set<int> >&, list< set<int> >&);
	void evaluar1(gatherset_t F) {
		cout << endl << "Evaluando ejercicio 1" << endl;
		int OK=0,TOT=0;
		verificar1(F, "3 5 7 11 3 0 1 3 3 1 2 10 3 7 13 22", 
                           "5 0 1 2 3 10 5 5 7 11 13 22", OK, TOT);
		verificar1(F, "2 0 1 2 0 4 3 2 3 5 2 5 7", "3 0 1 4 4 2 3 5 7",OK,TOT);
		verificar1(F, "3 0 1 2 3 1 2 3 3 2 3 4", "5 0 1 2 3 4",OK,TOT);
		verificar1(F, "5 0 1 2 3 4 2 1 5 2 6 7", "6 0 1 2 3 4 5 2 6 7",OK,TOT);
		cout << "EJERCICIO 1: Nro de tests " << TOT 
                     << ", OK " << OK 
                     << ".\n[EJ1] TODO OK? " << oksn(OK==TOT) << endl;
	}

	void verificar1(gatherset_t F, string s1, string s2,int &OK, int&TOT) {
		list< set<int> > L1, L2, R;
		s2ls(s1, L1);
		s2ls(s2, L2);
		F(L1, R);
		int ok1 = (R == L2);
		OK += ok1;
		TOT++;
		cout << "Test " << TOT << ", estado: "
			<< okbm(ok1) << endl;
	}

	typedef map<int,list<int> > graph_t;
	typedef set<int> (*maxshare_t)(vector< set<int> >&, set<int>&);

	void evaluar2(maxshare_t F) {
		cout << endl << "Evaluando ejercicio 2" << endl;
		int OK=0,TOT=0;
		verificar2(F, 
				"4 0 2 4 8 4 0 1 4 9 2 5 10 3 1 3 6", 
				"1 3 5", 
				"1 3 6",OK,TOT);
		verificar2(F, 
				"3 5 7 11 3 0 1 3 3 1 2 10 3 7 13 22", 
				"1 2 3 4", 
				"0 1 3",OK,TOT);
		verificar2(F, 
				"3 5 7 11 3 0 1 3 3 1 2 10 3 7 13 22", 
				"5", 
				"5 7 11",OK,TOT);       
		verificar2(F, 
				"3 5 7 11 3 0 1 3 3 1 2 10 3 7 13 22", 
				"0 1", 
				"0 1 3",OK,TOT);              
		verificar2(F, 
				"4 0 2 4 8 4 0 1 4 9 2 5 10 3 1 3 6", 
				"0 4", 
				"0 2 4 8",OK,TOT);                                                     
		cout << "EJERCICIO 2: Nro de tests " 
                     << TOT << ", OK " << OK 
                     << ".\n[EJ2] TODO OK? " << oksn(OK==TOT) << endl;
	}

	void verificar2(maxshare_t F, 
			string s1, string s2, string r,
			int &OK, int&TOT)     {
		vector< set<int> > vs;
		set<int> S, R1, R2;
		s2vs(s1, vs);
		s2s(s2, S);
		R1 = F(vs, S);
		s2s(r, R2);

		int ok1 = (R1==R2);
		OK += ok1;
		TOT++;
		cout << "Test " << TOT << ", estado: "
			<< (ok1? "BIEN" : "MAL") << endl;
	}

	typedef int (*sccount_t)(btree<int>&);

	void evaluar3(sccount_t F) {
		cout << endl << "Evaluando ejercicio 3" << endl;
		int OK=0,TOT=0;
		verificar3(F,"(8 (7 9 2) (3 . (9 . 1)))", 
				2,OK,TOT);

		verificar3(F,"(2 8 (1 (2 . 6) .))", 
				2,OK,TOT);

		verificar3(F,"(4 (9 (2 6 .) .) 8)", 
				2,OK,TOT);

		verificar3(F,"(8 (6 (5 . (4 3 (4 . (9 . 6)))) .) 3)", 
				4,OK,TOT);

		cout << "EJERCICIO 3: Nro de tests " 
                     << TOT << ", OK " << OK 
                     << ".\n[EJ3] TODO OK? " << oksn(OK==TOT) << endl;
	}

	void verificar3(sccount_t F,string t, int r,
			int &OK, int&TOT) {
		btree<int> T;
		int p;
		lisp2btree(t, T);
		p = F(T);
					
		int ok1 = (p == r);
		OK += ok1;
		TOT++;
		cout << "Test " << TOT << ", estado: "
			<< (ok1? "BIEN" : "MAL") << endl;
	}
};

  typedef list< set<int> > ls_t;
  void print(set<int> &S) {
    cout << "{";
    set<int>::iterator q=S.begin();
    while (q!=S.end()) {
      cout << *q;
      q++;
      if (q!=S.end()) cout << ",";
    }
   cout << "}";
  }

  void print(ls_t &LS) {
    ls_t::iterator q = LS.begin();
    int j=0;
    while (q!=LS.end()) {
      set<int> &S = *q;
      cout << "S" << j;
      print(S);
      cout << endl;
      q++;
    }
  }

  typedef vector< set<int> > vs_t;
  void print(vs_t &VS) {
    vs_t::iterator q = VS.begin();
    int j=0;
    while (q!=VS.end()) {
      set<int> &S = *q;
      cout << "S" << j;
      print(S);
      cout << endl;
      q++;
    }
  }

}

#endif
