#include <cstdio>

#include "Evaluar.hpp"
#include "./tree.h"
// #include "./util_tree.h"
// #include "./util.h"

//--------------------------------------------------------------------
void odd2even(list<int> &L,map<int,list<int> > &M) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool is_shift(graph_t &G1,graph_t &G2,int m) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
typedef tree<int> tree_t;
int count_level(tree_t &T,int l) {
  // COMPLETAR...
}

using namespace aed;
int main() {
  Evaluar ev;
  ev.evaluar1(count_level);
  ev.evaluar2(is_shift);
  ev.evaluar3(odd2even);
  return 0;
}
