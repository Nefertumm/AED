// GITVERSION: TPL-SUPREC-2015-16-g4c112db
#ifndef EVAL_HPP
#define EVAL_HPP
#include "aedtools/evalbase.hpp"

namespace aed {

  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef void (*mkstats_t)(vector<set<int> > &VS, map<int,int> &count);
  class eval1_t : public eval_base_t {
  public:
    mkstats_t F;
    eval1_t() { dumptests=0; F=NULL; ejerc=1; testfile="./tests1.json"; }
    void run_case(json &data,json &outuser) {
      json jVS = data["VS"];
      vector< set<int> > VS;
      auto p = jVS.begin();
      while (p!=jVS.end()) {
        vector<int> v = *p++;
        set<int> S;
        S.insert(v.begin(),v.end());
        VS.push_back(S);
      }
      map<int,int> count;
      F(VS,count);
      vector<int> vcount;
      auto q = count.begin();
      while (q!=count.end()) {
        vcount.push_back(q->first);
        vcount.push_back(q->second);
        q++;
      }
      outuser["count"] = vcount;
    }

    int check_case(json &datain,
                   json &outref,json &outuser) {
      vector<int> countref = outref["count"];
      vector<int> countuser = outuser["count"];
      return countuser==countref;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      int Nset = 4+rnd.rand()%4;
      json &jVS = datain["VS"];
      for (int j=0; j<Nset; j++) {
        set<int> S;
        for (int k=0; k<10; k++) S.insert(rnd.rand()%20);
        vector<int> v;
        v.insert(v.begin(),S.begin(),S.end());
        jVS.push_back(v);
      }
    }
  };

#if 0
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef int (*map_fun_t)(int);
  typedef bool (*ismapped_t)(tree<int> &T,tree<int> &Q,map_fun_t f);
  class eval2_t : public eval_base_t {
  public:
    ismapped_t F;
    eval2_t() { dumptests=0; F=NULL; ejerc=2; testfile="./tests2.json"; }
    void run_case(json &data,json &outuser) {
      tree<int> T,Q;
      lisp2tree(data["T"],T);
      lisp2tree(data["Q"],Q);
      int retval = F(T,Q,absfun);
      outuser["retval"] = retval;
    }

    int check_case(json &datain,
                   json &outref,json &outuser) {
      int rvuser = outuser["retval"];
      int rvref = outref["retval"];
      return rvuser==rvref;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
    }
  };
#endif

  typedef int (*mapfunc_t)(int);
  typedef bool (*ismaptree_t)(tree<int> &,tree<int> &,mapfunc_t);
  
  class eval2_t : public eval_base_t {
    // posibles funciones para f
    static int doble(int x) { return 2*x; }
    static int triple(int x) { return 3*x; }
    static int cuadrado(int x) { return x*x; }
    static int opuesto(int x) { return -x; }
    static int mas_uno(int x) { return x+1; }
    static int menos_uno(int x) { return x-1; }
    vector<pair<string,mapfunc_t>> vfuncs = { 
      {"doble",doble}, {"triple",triple},
      {"cuadrado",cuadrado}, {"opuesto",opuesto},
      {"mas_uno",mas_uno}, {"menos_uno",menos_uno} };
    mapfunc_t get_mapfunc(string name) {
      for(auto &x:vfuncs) if (x.first==name) return x.second;
      assert(false); // no debería pasar
    }
    
  public:
    ismaptree_t F;
    eval2_t() { dumptests=0; F=NULL; ejerc=2; testfile="./mapfunc.json"; }
    void run_case(json &data,json &outuser) {
        tree<int> T1; lisp2tree(data["T1"],T1);
        tree<int> T2; lisp2tree(data["T2"],T2);
        mapfunc_t func = get_mapfunc(data["func"]);
        outuser["retval"] = F(T1,T2,func);
    }

    int check_case(json &datain, json &outref,json &outuser) {
      btree<int> Tref, Tuser;
      bool Rref = outref["retval"];
      bool Ruser = outuser["retval"];
      return Rref==Ruser;
    }
    
    void make_trees(tree<int> &T1, tree<int>::iterator it1, 
                    tree<int> &T2, tree<int>::iterator it2,
                    mapfunc_t f,randomg_t &rnd, int nlevels,
                    int nchilds, int mutation) 
    {
      if (nlevels<0 || nchilds==0) return;
      for(int i=0;i<nchilds;i++) { 
        int val = rnd.rand()%25;
        it1 = T1.insert(it1,val);
        it2 = T2.insert(it2,f(val));
        int aux_childs = rnd.rand()%5; // entre 0 y 4 hijos por cada nodo
        make_trees(T1,it1.lchild(),T2,it2.lchild(),f,rnd,nlevels-1,aux_childs,mutation);
        // con estas probabilidades (8,8,6 en los rand()%x), un caso con mutate!=0 
        // podría dar verdadero, en promedio un poco más de la mitad de los casos da falso
        switch (mutation) { 
        case 1: if (rnd.rand()%8==0) it1 = T1.erase(it1); break; // it1==T1.end() && it2!=T2.end()
        case 2: if (rnd.rand()%8==0) it2 = T2.erase(it2); break; // it1!=T1.end() && it2==T2.end() 
        case 3: if (*it2!=0 && rnd.rand()%6==0) *it2 += (rnd.rand()%(*it2))+1; break; // it1 != f(*it2)
        default: ; // no cambia nada
        }
      }
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      auto &f = vfuncs[rnd.rand()%vfuncs.size()];
      tree<int> T1, T2;
      int nlevels = rnd.rand()%3+5; // entre 3 y 7 niveles
      
      int mutation = rnd.rand()%4; // 0 = debe dar true, 1/2 = cambia la forma, 3 = cambia algun valor
      make_trees(T1,T1.begin(),T2,T2.begin(),f.second,rnd,nlevels,1,mutation);
      datain["T1"] = lisp_print(T1);
      datain["T2"] = lisp_print(T2);
      datain["func"] = f.first;
    }
  };
  
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef bool (*leiafunc_t)(string,string);
  typedef bool (*foodplan_t)(vector<list<string>> &plan,
                             leiafunc_t f, set<string> &alternatives);
  
  class eval3_t : public eval_base_t {
    
    // posibles funciones para f
    static bool distintas(string f1, string f2) { return f1!=f2; }
    static bool distinta_inicial(string f1, string f2) { return f1[0]!=f2[0]; }
    static bool distinta_cant_letras(string f1, string f2) { return f1.size()!=f2.size(); }
    vector<pair<string,leiafunc_t>> vfuncs = { 
      {"distintas",distintas}, {"distinta_inicial",distinta_inicial},
      {"distinta_cant_letras",distinta_cant_letras} };
    leiafunc_t get_leiafunc(string name) {
      for(auto &x:vfuncs) if (x.first==name) return x.second;
      assert(false); // no debería pasar
    }
    
    // funciones auxiliares para armar los vectores, listas y conjuntos
    vector<string> str2foods(string str) {
      stringstream ss(str); string s;
      vector<string> v;
      while (ss>>s)  v.push_back(s);
      return v;
    }
    
    vector<list<string>> str2vl(string str) {
      vector<list<string>> vl;
      stringstream ss(str);
      string aux;
      while (true) {
        while (ss>>aux && aux!="(");
        if (!ss) return vl;
        vl.push_back(list<string>());
        for(int i=0;i<7;i++) { 
          ss>>aux;
          vl.back().push_back(aux);
        }
        while (ss>>aux && aux!=")");
      }
    }
    
    string vl2str(vector<list<string>> &vl) {
      string s;
      for(auto &l:vl) {
        s+="( ";
        for(string &f:l) s+=f+" ";
        s+=") ";
      }
      if (!s.empty()) s.erase(s.size()-1,1);
      return s;
    }
    
    string set2str(set<string> &st) {
      string str;
      for(const string &s:st)
        str += s+" ";
      if (str.size()) str.erase(str.size()-1,1);
      return str;
    }
    
    set<string> str2set(string str) {
      set<string> st;
      stringstream ss(str);
      string aux;
      while(ss>>aux) st.insert(aux);
      return st;
    }
    
  public:
    foodplan_t F;
    eval3_t() { dumptests=0; F=NULL; ejerc=3; testfile="./foodplan.json"; }
    void run_case(json &data,json &outuser) {
        vector<list<string>> vl = str2vl(data["plan"]);
        set<string> s = str2set(data["alternatives"]);
        leiafunc_t f = get_leiafunc(data["func"]);
        bool retval = F(vl,f,s);
        outuser["retval"] = retval;
        outuser["plan"] = retval?vl2str(vl):""; // si el usuario retorno false no guardo el plan fallido para que el hash de siempre igual sin importar que hizo o no con ese plan
    }

    int check_case(json &datain, json &outref,json &outuser) {
      bool Rref = outref["retval"];
      bool Ruser = outuser["retval"];
      string Pref = outref["plan"];
      string Puser = outuser["plan"];
      return Rref==Ruser && (!Rref || Puser==Pref);
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      vector<string> foods = {
        "Pizza","Hamburguesas","Tarta","Empanadas","Milanesas","Ensalada",
        "Asado","Pollo","Albondigas","Tacos","Sandwiches","Pescado","Spagetti",
        "Ravioles","Noquis","Polenta","Frutas","Tallarines","Omelette","Arroz" };
      // armar el plan
      int weeks = 1+rnd.rand()%3; // de 1 a 4 semanas
      vector<list<string>> vl;
      for(int i=0;i<weeks;i++) { 
        vl.push_back(list<string>());
        for(int j=0;j<7;j++) { 
          vl.back().push_back(foods[rnd.rand()%foods.size()]);
        }
      }
      datain["plan"] = vl2str(vl);
      // alternativas
      int nalt = rnd.rand()%4; // de 0 a 3 alternativas, genera entre 3 y 10 falsos para los 50 casos
      set<string> s;
      for(int i=0;i<nalt;i++) 
        s.insert(foods[rnd.rand()%foods.size()]);
      datain["alternatives"] = set2str(s);
      datain["func"] = vfuncs[rnd.rand()%vfuncs.size()].first;
    }
    
  };
  
  
  typedef int (*minsublist_t)(list<int> &L);
  class eval4_t : public eval_base_t {
  public:
    eval4_t() { dumptests=0; F=NULL; ejerc=4; testfile="./tests4.json"; }
    minsublist_t F;
    void run_case(json &datain,json &outuser) {
      list<int> L; 
      auto p = datain["L"].begin();
      while (p!=datain["L"].end()) {
        L.push_back(*p++);
      }
      outuser["S"] = F(L);
    }
    
    int check_case(json &datain,
      json &outref,json &outuser) {
        int iuser = outuser["S"];
        int iref = outref["S"];
        return iuser==iref;	   
      }
    
    void generate_case(randomg_t &rnd,json &datain) {
      int N = rnd.rand()%15;
      list<int> L;
      for (int j=0; j<N; j++) {
        L.push_back(rnd.rand()%20 - 10);
        // printf("Nset %d, Nchar %d\n",Nset,Nchar);
      }
      datain["L"] = L;
    }
  };
  
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  using Eval = eval_t<
    eval1_t,mkstats_t,
    eval2_t,ismaptree_t,
    eval3_t,foodplan_t,
    eval4_t,minsublist_t>;
  
}

#endif
