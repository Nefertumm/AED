#include "eval.hpp"
#include <climits>
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

void mkstats(vector<set<int> > &VS, map<int,int> &count) {
}

bool ismaptree(tree<int> &T1, tree<int> &T2, mapfunc_t f) {
  return true;
}

bool foodplan(vector<list<string>> &plan, leiafunc_t f,
              set<string> &alternatives) {
  return true;
}

int minsublist(list<int>& L){
  return 0;
}

int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0,h4=0;

  ev.eval<1>(mkstats,vrbs);
  h1 = ev.evalr<1>(mkstats,seed,vrbs);

  ev.eval<2>(ismaptree,vrbs);
  h2 = ev.evalr<2>(ismaptree,seed,vrbs);
  
  ev.eval<3>(foodplan,vrbs);
  h3 = ev.evalr<3>(foodplan,seed,vrbs);

  ev.eval<4>(minsublist,vrbs);
  h4 = ev.evalr<4>(minsublist,seed,vrbs);

  // Debe dar S=123 -> H1=718 H2=536 H3=122 H4=046
  printf("S=%03d -> H1=%03d H2=%03d H3=%03d H4=%03d\n",
         seed,h1,h2,h3,h4);

  return 0;
}
