// GITVERSION: tpl1-recup-2015-32-gd022f91
#include "eval.hpp"
#include <climits>
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

// Retorna true si L1 es prefijo de L2
bool isprefix(list<int> &L1, list<int> &L2) {
  // COMPLETAR AQUI....
  return false;
}

// Retorna true si L es una combinacion de los VL
bool iscomb(vector< list<int> > &VL, list<int> &L) {
  // COMPLETAR AQUI....
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
// Retorna la sublista contigua cuya suma es maxima
list<int> max_sublist(list<int> &L){
  return list<int>();    
}

// Fusiona dos listas ordenadas L1,L2 en L
void merge(list<int> &L1, list<int> &L2, list<int>& L){
  // COMPLETAR AQUI....
}

// Ordena una lista L por fusión recursiva
void mergesort(list<int>&L){
  // COMPLETAR AQUI....
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;

  ev.eval1(iscomb,vrbs);
  ev.eval2(max_sublist,vrbs);
  ev.eval3(mergesort,vrbs);
  return 0;
}
