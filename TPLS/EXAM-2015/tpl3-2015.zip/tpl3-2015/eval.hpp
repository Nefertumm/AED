// GITVERSION: tpl2-recup-2015-89-g7238088
#ifndef EVAL_HPP
#define EVAL_HPP
#include "evalbase.hpp"

namespace aed {

  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef void (*mkheaptree_t)(btree<int> &T,int nlev,int root);
  class eval1_t : public eval_base_t {
  public:
    mkheaptree_t F;
    eval1_t() { dumptests=0; F=NULL; ejerc=1; testfile="./tests1.json"; }
    void run_case(json &data,json &outuser) {
      int nlev = data["nlev"];
      int root = data["root"];
      btree<int> Tuser;
      F(Tuser,nlev,root);
      outuser["T"] = lisp_print(Tuser);
    }

    int check_case(json &datain,
                   json &outref,json &outuser) {
      btree<int> Tref, Tuser;
      lisp2btree(outref["T"],Tref);
      lisp2btree(outuser["T"],Tuser);
      return Tref==Tuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      datain["nlev"] = 1+rnd.rand()%4;
      datain["root"] = rnd.rand()%10;
    }
  };

  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef int (*find_word_t)( btree<char> &t, string s);
  class eval2_t : public eval_base_t {
	  
    //genera arbol con char aleatorio
    void make_random_btree(randomg_t &rnd, btree<char> &t,btree<char>::iterator n,
                           int m,int level,double siblings) {
      btree<char>::iterator c;
      double lambda,nivel;
      n=t.insert(n,rnd.rand()%('z'-'a'+1)+'a');
      nivel=double(level);
      lambda = 1.0/(siblings/nivel+1.0);
      for (int j=0;j<2;j++) {
        if  (j==0) {
          c=n.left();}
        else {
          c=n.right();
        }
        float r = rnd.drand();
        if (r>lambda) {
          make_random_btree(rnd,t,c,m,level+1,siblings);
        }
      }
    }
    // -----------------------------------------------------------------
    void make_random_btree(randomg_t &rnd, btree<char> &t,int m,double siblings) {
      t.clear();
      make_random_btree(rnd,t,t.begin(),m,0,siblings);
    }
    void fvec(btree<char> &t, vector<string> &v, btree<char>::iterator it, size_t actual_level=0){
      if(it == t.end()) return;
      while (v.size()<=actual_level) v.push_back("");
      v[actual_level]+=*it;
      fvec(t,v,it.left(),actual_level+1);
      fvec(t,v,it.right(),actual_level+1);
    }
	  
	  
  public:
    
    find_word_t F;
    eval2_t() {
      facmax=5.0; dumptests=0; F=NULL;
      ejerc=2; testfile="./tests2.json";
    }
    
    void run_case(json &datain,json &outuser) {
      btree<char> t; lisp2btree(datain["t"],t);
      string word = datain["word"];
      outuser["retval"] = F(t,word);
    }
    
    int check_case(json &datain, json &outref,json &outuser) {
      int iuser = outuser["retval"];
      int iref = outref["retval"];
      return iuser==iref;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      btree<char> t;		
      // int levels = (rnd.rand()%100)*fac; // no se usa
      int siblings = 5*fac;
      make_random_btree(rnd,t,0,siblings); //arbol aleatorio
      // cout << t.size() << endl;
      vector <string> v;
      fvec(t,v,t.begin()); //lleno vector con palabras
      string word;
      if(rnd.rand()%10 == 0){ //si es 0, genera un string aleatorio que probablemente no est� en el arbol
        for(int i=0; i <= 9; i++)
          word += ('a' + rand() % ('z'-'a'+1));
      }else{ //sino extrae un substring de manera aleatoria entre los existentes
        int lvl = rnd.rand()%v.size(); //nivel random
        int s_from = rnd.rand()%(v[lvl].size()); //desde donde comienza a sacar
        int s_many = rnd.rand()%(v[lvl].size()-s_from)+1; //cuantos caracteres sacar - el +1 es para que no sea cero
        word = v[lvl].substr(s_from,s_many); //extrae la cadena
      }
      datain["t"] = lisp_print(t);
      datain["word"] = word;
    }
    
  };
  
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef bool (*func_t)(pair<int,int>);
  typedef pair<int,int> pair_t;
  bool affordable(pair_t p);
  typedef set<pair<int,int>> (*fillcp_t)(set<int>& S1, set<int>& S2, func_t f);
  class eval3_t : public eval_base_t {
  public:
    fillcp_t F;
    eval3_t() { dumptests=0; F=NULL; ejerc=3; testfile="./tests3.json"; }
    void run_case(json &datain,json &outuser) {
      set<int> S1, S2;
      for(unsigned int i=0;i<datain["S1"].size();i++)
        S1.insert(int(datain["S1"][i]));
      for(unsigned int i=0;i<datain["S2"].size();i++)
        S2.insert(int(datain["S2"][i]));
      set<pair<int,int>> user = F(S1,S2,affordable);
#if 0
      ostringstream os;
      for(pair_t p : user){
        os << p.first <<" "<<p.second<<" ";
      }
      outuser["R"] = os.str();
#else
      json &R = outuser["R"];
      for(pair_t p : user) {
        R.push_back(p.first);
        R.push_back(p.second);
      }
#endif
    }
    int check_case(json &datain, json &outref,json &outuser) {
      vector<int> iuser,iref;
      for (auto x : outuser["R"]) iuser.push_back(x);
      for (auto x : outref["R"]) iref.push_back(x);
      return iuser==iref;
    }
    void generate_case(randomg_t &rnd,json &datain) {
      set<int> S1, S2;
      int Nset1 = rnd.rand()%10;
      int Nset2 = rnd.rand()%10;
      for(int i=0;i<Nset1;i++) S1.insert(rnd.rand()%10);
      for(int i=0;i<Nset2;i++) S2.insert(rnd.rand()%10);
      datain["S1"] = S1;
      datain["S2"] = S2;
    }
  };
  
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  typedef int (*greatest_subset_t)( vector<set<char> > &vs,string s);
  class eval4_t : public eval_base_t {
  public:
    greatest_subset_t F;
    eval4_t() {
      facmax=500.0; dumptests=0;
      F=NULL; ejerc=4; testfile="./tests4.json";
    }
    void run_case(json &datain,json &outuser) {
      vector< set<char> > vs;
      json &dts = datain["vs"];
      auto p = dts.begin();
      while (p!=dts.end()) {
        string w =*p++;
        set<char> cs;
        for (unsigned int j=0; j<w.size(); j++) cs.insert(w[j]);
        vs.push_back(cs);
      }
      string s = datain["s"];
      outuser["retval"] = F(vs,s);
    }

    int check_case(json &datain,
                   json &outref,json &outuser) {
      int iuser = outuser["retval"];
      int iref = outref["retval"];
      return iuser==iref;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      int Nset = fac*(4+rnd.rand()%4);
      vector<string> vs;
      for (int j=0; j<Nset; j++) {
        int Nchar = fac*(4+rnd.rand()%4);
        // printf("Nset %d, Nchar %d\n",Nset,Nchar);
        set<char> w;
        for (int k=0; k<Nchar; k++) w.insert(97+rnd.rand()%6);
        Nchar = w.size();
        string vc;
        set<char>::iterator p = w.begin();
        while (p!=w.end()) vc.push_back(*p++);
        vs.push_back(vc);
      }
      datain["s"] = vs[0];
      vs.erase(vs.begin());
      datain["vs"] = vs;
    }
  };
  
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  using Eval = eval_t<
	  eval1_t,mkheaptree_t,
	  eval2_t,find_word_t, 
	  eval3_t,fillcp_t,
	  eval4_t,greatest_subset_t
	  >;
  
}
#undef CSTR

#endif
