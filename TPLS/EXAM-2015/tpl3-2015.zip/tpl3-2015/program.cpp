#include "eval.hpp"
#include <climits>
#include <cstdlib>
#include <stack>
#include <algorithm>

using namespace aed;
using namespace std;

typedef int (*map_fun_t)(int);

// * Completar los datos.
// * No borrar las lineas "(BEGIN|END) USERCODE"
//   ya que son necesarias para la evaluacion automatica
//   del Torneo.
// --- <<BEGIN-USERCODE>> -----
// NOMBRE:
// DNI:
// NICK: 
void mkheaptree(btree<int> &T,int nlev,int root) {
  // COMPLETAR AQUI...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int greatest_subset( vector<set<char> > &vs, string s ){
  // COMPLETAR AQUI...
  return 0;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int find_word( btree<char> &t, string s){
  // COMPLETAR AQUI...
  return -1;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool aed::affordable(pair_t p){
  // COMPLETAR AQUI...
  return true;
}

set<pair_t> filtcp(set<int>& S1, set<int>& S2, func_t f){
  // COMPLETAR AQUI...
  return set<pair_t>();
}
// --- <<END-USERCODE>> -----

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
	
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0,h4=0;

  ev.eval<1>(mkheaptree,vrbs);
  h1 = ev.evalr<1>(mkheaptree,seed,vrbs);

  ev.eval<2>(find_word,vrbs);
  h2 = ev.evalr<2>(find_word,seed,vrbs);
  
  ev.eval<3>(filtcp,vrbs);
  h3 = ev.evalr<3>(filtcp,seed,vrbs);

  ev.eval<4>(greatest_subset,vrbs);
  h4 = ev.evalr<4>(greatest_subset,seed,vrbs);

  // Para S=123 debe dar ->  H1=576 H2=651 H3=857 H4=856
  printf("S=%03d -> H1=%03d H2=%03d H3=%03d H4=%03d\n",
         seed,h1,h2,h3,h4);
  
  return 0;
}
